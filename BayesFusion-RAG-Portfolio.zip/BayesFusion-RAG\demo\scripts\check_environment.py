#!/usr/bin/env python3
import sys
import platform

print("=" * 50)
print("  Environment Check")
print("=" * 50)
print(f"\nPython: {sys.version.split()[0]}")
print(f"Platform: {platform.system()} {platform.release()}")

deps = [
    ("torch", "PyTorch"),
    ("numpy", "NumPy"),
    ("transformers", "Transformers"),
    ("yaml", "PyYAML"),
]

print("\nDependencies:")
for mod, name in deps:
    try:
        m = __import__(mod)
        ver = getattr(m, "__version__", "installed")
        print(f"  [OK] {name}: {ver}")
    except ImportError:
        print(f"  [--] {name}: not found")

print("\n" + "=" * 50)
