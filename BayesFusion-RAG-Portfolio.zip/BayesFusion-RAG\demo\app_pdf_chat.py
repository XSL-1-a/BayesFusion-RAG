#!/usr/bin/env python3
"""
PDF RAG 智能问答系统 v2
=======================
基于 MoRE 检索 + 千问 7B 生成

功能:
1. 图片上传识别 - 找到图片在哪个 PDF 的哪页
2. 标号查询 - "14号是什么"
3. Warning 搜索 - "总结所有 warning"
4. 表格查询 - "给我 xxx PDF 的前3个表格"
5. 跨文档综合问答

运行: python demo/app_pdf_chat.py
"""

import os
import sys

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
# 离线模式：绕过代理，确保本地通信正常
os.environ.setdefault('no_proxy', '127.0.0.1,localhost')
# 完全离线模式：不检查 HuggingFace 更新，直接使用本地缓存
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'

# 修复 cuDNN 版本冲突：使用 PyTorch 自带的 cuDNN 9.10.2
# 在 import torch 之前，用 ctypes 预加载正确版本的 cuDNN
def preload_cudnn():
    """预加载 PyTorch 自带的 cuDNN 库，避免版本冲突"""
    import ctypes
    venv_path = sys.prefix
    cudnn_lib_dir = os.path.join(venv_path, 'lib/python3.12/site-packages/nvidia/cudnn/lib')

    if not os.path.exists(cudnn_lib_dir):
        return  # 没有找到，跳过

    # 预加载所有 cuDNN 库（按依赖顺序，包括 engines）
    cudnn_libs = [
        'libcudnn.so.9',
        'libcudnn_ops.so.9',
        'libcudnn_graph.so.9',
        'libcudnn_cnn.so.9',
        'libcudnn_adv.so.9',
        'libcudnn_heuristic.so.9',
        'libcudnn_engines_precompiled.so.9',
        'libcudnn_engines_runtime_compiled.so.9',
    ]

    for lib_name in cudnn_libs:
        lib_path = os.path.join(cudnn_lib_dir, lib_name)
        if os.path.exists(lib_path):
            try:
                ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
            except OSError:
                pass  # 忽略加载失败

preload_cudnn()

import json
import re
import math
import numpy as np
import torch
import gradio as gr
from pathlib import Path
from collections import Counter, defaultdict
from typing import Dict, List, Tuple, Optional
from PIL import Image
import logging
import warnings
warnings.filterwarnings('ignore')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================================================
# PDF 数据加载
# ============================================================================

class PDFKnowledgeBase:
    """PDF 知识库"""

    def __init__(self, data_dir: str = './data/processed', single_file: str = None):
        self.data_dir = Path(data_dir)
        self.single_file = single_file  # 单文件模式
        self.documents = {}
        self.chunks = []
        self.images = []
        self.chunk_index = {}
        self.doc_chunks = defaultdict(list)
        self.doc_images = defaultdict(list)
        self.tables = []  # 表格内容

    def load_all(self, progress_callback=None):
        """加载所有 PDF 数据"""
        if self.single_file:
            # 单文件模式
            sf = Path(self.single_file)
            if not sf.suffix:
                sf = sf.with_suffix('.json')
            json_files = [sf] if sf.exists() else []
            logger.info(f"单文件模式: {sf}")
        else:
            json_files = list(self.data_dir.glob('*.json'))

        for i, jf in enumerate(json_files):
            if progress_callback:
                progress_callback(i / len(json_files), f"加载 {jf.stem[:30]}...")

            with open(jf, 'r', encoding='utf-8') as f:
                data = json.load(f)

            doc_id = jf.stem
            doc_title = data.get('document', {}).get('title', doc_id)

            self.documents[doc_id] = {
                'title': doc_title,
                'path': str(jf),
                'n_chunks': len(data.get('chunks', [])),
                'n_images': len(data.get('images', []))
            }

            # 加载 chunks
            for chunk in data.get('chunks', []):
                chunk['doc_id'] = doc_id
                chunk['doc_title'] = doc_title
                self.chunks.append(chunk)
                self.chunk_index[chunk['chunk_id']] = chunk
                self.doc_chunks[doc_id].append(chunk)

                # 检测表格内容 - 改进检测逻辑
                content = chunk.get('content', '')
                chunk_id = chunk.get('chunk_id', '')
                content_upper = content[:500].upper()

                # 检测条件：
                # 1. chunk_id 包含 complete_table（完整表格提取）
                # 2. 包含 LIST、PARTS LIST、TABLE 等关键词
                # 3. 包含 '|' 表格符号
                is_table = (
                    'complete_table' in chunk_id or
                    'LIST' in content_upper or
                    'PARTS' in content_upper or
                    'APPENDIX' in content_upper or
                    'table' in content.lower() or
                    '|' in content
                )

                if is_table:
                    self.tables.append({
                        'doc_id': doc_id,
                        'doc_title': doc_title,
                        'page': chunk.get('page', 'N/A'),
                        'content': content,
                        'chunk_id': chunk_id,
                        'is_complete_table': 'complete_table' in chunk_id
                    })

            # 加载 images
            for img in data.get('images', []):
                img['doc_id'] = doc_id
                img['doc_title'] = doc_title
                self.images.append(img)
                self.doc_images[doc_id].append(img)

            # 加载 sections 作为可检索内容（包含完整章节内容）
            for sec in data.get('sections', []):
                title = sec.get('title', '')
                content = sec.get('content', '') or ''
                abstract = sec.get('abstract', '')
                # 优先使用 content，如果没有则使用 abstract
                section_content = content if content else abstract
                # 只加载有实质内容的 section
                if len(section_content) >= 50 or (title and len(title) >= 10):
                    full_content = f"## {title}\n\n{section_content}".strip() if section_content else title
                    sec_chunk = {
                        'chunk_id': f"{sec.get('section_id', '')}_sec",
                        'doc_id': doc_id,
                        'doc_title': doc_title,
                        'content': full_content,
                        'page': sec.get('start_page', 'N/A'),
                        'end_page': sec.get('end_page', sec.get('start_page', 'N/A')),
                        'source': 'section',  # 标记来源
                        'section_title': title
                    }
                    self.chunks.append(sec_chunk)
                    self.chunk_index[sec_chunk['chunk_id']] = sec_chunk
                    self.doc_chunks[doc_id].append(sec_chunk)

        logger.info(f"加载完成: {len(self.documents)} 文档, {len(self.chunks)} chunks (含sections), {len(self.images)} 图片, {len(self.tables)} 表格")
        return len(self.documents), len(self.chunks), len(self.images)

    def get_doc_list(self) -> List[str]:
        """获取文档列表"""
        return ["所有文档"] + [f"{doc_id} ({info['n_chunks']} chunks)"
                             for doc_id, info in self.documents.items()]

    def get_tables_by_doc(self, doc_id: str = None, limit: int = 5) -> List[dict]:
        """获取指定文档的表格"""
        if doc_id and doc_id != "所有文档":
            # 提取真实 doc_id
            real_doc_id = doc_id.split(" (")[0] if " (" in doc_id else doc_id
            tables = [t for t in self.tables if t['doc_id'] == real_doc_id]
        else:
            tables = self.tables
        return tables[:limit]


# ============================================================================
# 图片匹配器
# ============================================================================

class ImageMatcher:
    """图片匹配 - 找到上传图片对应的 PDF 页面"""

    def __init__(self, cache_dir: str = './data/cache'):
        self.model = None
        self.image_embeddings = {}
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_device(self):
        """智能选择设备：优先 GPU"""
        if torch.cuda.is_available():
            return 'cuda'
        return 'cpu'

    def load_model(self):
        if self.model is None:
            device = self._get_device()
            logger.info(f"CLIP 模型使用设备: {device}")
            local_clip = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models', 'CLIP-ViT-Large')
            if os.path.exists(local_clip):
                # 本地 CLIP 模型是原始 HuggingFace 格式，用 transformers 加载
                from transformers import CLIPModel, CLIPProcessor
                self._clip_model = CLIPModel.from_pretrained(local_clip).to(device)
                self._clip_processor = CLIPProcessor.from_pretrained(local_clip)
                self._use_transformers_clip = True
                self.model = True  # 标记已加载
            else:
                from sentence_transformers import SentenceTransformer
                self._use_transformers_clip = False
                self.model = SentenceTransformer('clip-ViT-B-32', device=device)

    def encode(self, inputs, **kwargs):
        """统一的编码接口，兼容两种 CLIP 加载方式"""
        if self._use_transformers_clip:
            device = self._get_device()
            batch_size = kwargs.get('batch_size', 32)
            all_embs = []
            is_image = isinstance(inputs[0], Image.Image)
            # 分批处理避免显存不足
            for i in range(0, len(inputs), batch_size):
                batch = inputs[i:i+batch_size]
                if is_image:
                    processed = self._clip_processor(images=batch, return_tensors="pt", padding=True).to(device)
                    with torch.no_grad():
                        embs = self._clip_model.get_image_features(**processed)
                else:
                    processed = self._clip_processor(text=batch, return_tensors="pt", padding=True, truncation=True).to(device)
                    with torch.no_grad():
                        embs = self._clip_model.get_text_features(**processed)
                embs = embs / embs.norm(dim=-1, keepdim=True)
                all_embs.append(embs.cpu().numpy())
            return np.concatenate(all_embs, axis=0)
        else:
            return self.model.encode(inputs, **kwargs)

    def _get_cache_path(self, data_dir: Path) -> Path:
        """生成缓存文件路径"""
        import hashlib
        # 基于数据目录生成唯一缓存名
        dir_hash = hashlib.md5(str(data_dir.resolve()).encode()).hexdigest()[:8]
        return self.cache_dir / f"image_embeddings_{dir_hash}.pkl"

    def _load_cache(self, cache_path: Path, images: List[dict]) -> bool:
        """尝试加载缓存"""
        import pickle
        if not cache_path.exists():
            return False

        try:
            with open(cache_path, 'rb') as f:
                cached_data = pickle.load(f)

            # 验证缓存有效性：检查图片数量是否匹配
            if cached_data.get('n_images') != len(images):
                logger.info(f"缓存失效：图片数量变化 ({cached_data.get('n_images')} -> {len(images)})")
                return False

            self.image_embeddings = cached_data.get('embeddings', {})
            logger.info(f"从缓存加载了 {len(self.image_embeddings)} 张图片的 embeddings")
            return True
        except Exception as e:
            logger.warning(f"加载缓存失败: {e}")
            return False

    def _save_cache(self, cache_path: Path, n_images: int):
        """保存缓存"""
        import pickle
        try:
            cached_data = {
                'n_images': n_images,
                'embeddings': self.image_embeddings
            }
            with open(cache_path, 'wb') as f:
                pickle.dump(cached_data, f)
            logger.info(f"缓存已保存: {cache_path}")
        except Exception as e:
            logger.warning(f"保存缓存失败: {e}")

    def _load_images_parallel(self, image_paths: List[str], max_workers: int = 8) -> List[Image.Image]:
        """多线程并行加载图片"""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def load_single(path):
            try:
                return Image.open(path).convert('RGB')
            except:
                return Image.new('RGB', (224, 224))

        pil_images = [None] * len(image_paths)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_idx = {executor.submit(load_single, p): i for i, p in enumerate(image_paths)}
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                pil_images[idx] = future.result()

        return pil_images

    def index_images(self, images: List[dict], data_dir: Path, progress_callback=None):
        """索引所有 PDF 图片（支持缓存和 GPU 加速）"""
        # 项目根目录 - 使用绝对路径
        data_dir_abs = data_dir.resolve()
        project_root = data_dir_abs.parent.parent if data_dir_abs.name == 'processed' else data_dir_abs.parent
        logger.info(f"图片索引: data_dir={data_dir_abs}, project_root={project_root}")

        # 尝试加载缓存
        cache_path = self._get_cache_path(data_dir)
        if self._load_cache(cache_path, images):
            if progress_callback:
                progress_callback(1.0, f"从缓存加载了 {len(self.image_embeddings)} 张图片")
            return

        # 缓存未命中，需要重新索引
        self.load_model()
        self.images = images

        valid_images = []
        image_paths = []

        for img in images:
            img_rel_path = img.get('image_path', '')
            img_path = project_root / img_rel_path
            if img_path.exists():
                valid_images.append(img)
                image_paths.append(str(img_path))

        if not image_paths:
            logger.warning("没有找到有效的图片文件")
            return

        if progress_callback:
            progress_callback(0.2, f"并行加载 {len(image_paths)} 张图片...")

        # 多线程并行加载图片
        pil_images = self._load_images_parallel(image_paths)

        if progress_callback:
            progress_callback(0.5, f"编码 {len(image_paths)} 张图片 ({self._get_device()})...")

        # 使用更大的 batch_size（GPU 可以更大）
        batch_size = 64 if self._get_device() == 'cuda' else 32
        embeddings = self.encode(pil_images, show_progress_bar=True, batch_size=batch_size)

        for img, emb in zip(valid_images, embeddings):
            self.image_embeddings[img['image_id']] = {
                'embedding': emb,
                'info': img
            }

        # 保存缓存
        self._save_cache(cache_path, len(images))

        logger.info(f"索引了 {len(self.image_embeddings)} 张图片")

    def find_similar(self, uploaded_image: Image.Image, top_k: int = 5) -> List[dict]:
        """查找相似图片"""
        if not self.image_embeddings:
            return []

        self.load_model()

        # 编码上传的图片
        query_emb = self.encode([uploaded_image])[0]

        # 计算相似度
        results = []
        for img_id, data in self.image_embeddings.items():
            similarity = np.dot(query_emb, data['embedding']) / (
                np.linalg.norm(query_emb) * np.linalg.norm(data['embedding'])
            )
            results.append({
                'image_id': img_id,
                'similarity': float(similarity),
                'doc_id': data['info'].get('doc_id'),
                'doc_title': data['info'].get('doc_title'),
                'page': data['info'].get('page'),
                'image_path': data['info'].get('image_path')
            })

        results.sort(key=lambda x: x['similarity'], reverse=True)
        return results[:top_k]


# ============================================================================
# MoRE 检索器
# ============================================================================

class BM25Retriever:
    def __init__(self, k1=1.5, b=0.3):
        # b=0.3: 降低文档长度惩罚，让长表格也能被检索到
        # 原来 b=0.75 导致长文档（如完整表格）排名过低
        self.k1, self.b = k1, b

    def index(self, chunks: List[dict]):
        self.chunks = chunks
        self.doc_freqs = Counter()
        self.doc_lens = {}
        self.doc_term_freqs = {}

        for i, chunk in enumerate(chunks):
            text = chunk.get('content', '')
            tokens = text.lower().split()
            self.doc_lens[i] = len(tokens)
            self.doc_term_freqs[i] = Counter(tokens)
            self.doc_freqs.update(set(tokens))

        self.avg_dl = np.mean(list(self.doc_lens.values())) if self.doc_lens else 1
        self.n_docs = len(chunks)

    def search(self, query: str, top_k: int = 20, doc_filter: str = None) -> Dict[int, float]:
        q_tokens = query.lower().split()
        scores = {}

        for idx in range(self.n_docs):
            # 文档过滤
            if doc_filter and doc_filter != "所有文档":
                real_doc_id = doc_filter.split(" (")[0]
                if self.chunks[idx].get('doc_id') != real_doc_id:
                    continue

            score = 0.0
            dl = self.doc_lens[idx]
            tf_dict = self.doc_term_freqs[idx]
            chunk = self.chunks[idx]
            chunk_id = chunk.get('chunk_id', '')

            for token in q_tokens:
                if token in tf_dict:
                    tf = tf_dict[token]
                    df = self.doc_freqs[token]
                    idf = math.log((self.n_docs - df + 0.5) / (df + 0.5) + 1)
                    tf_norm = (tf * (self.k1 + 1)) / (tf + self.k1 * (1 - self.b + self.b * dl / self.avg_dl))
                    score += idf * tf_norm

            if score > 0:
                # 对表格类 chunk 给予额外加分（它们包含实际数据）
                if 'complete_table' in chunk_id or 'list_' in chunk_id.lower():
                    score *= 2.0  # 表格类 chunk 得分翻倍
                scores[idx] = score

        return dict(sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k])


class DenseRetriever:
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        # 优先使用本地模型
        local_model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models', 'bge-small-zh-v1.5')
        if os.path.exists(local_model_path):
            self.model_name = local_model_path
        else:
            self.model_name = model_name
        self.model = None
        self.embeddings = None

    def load_model(self):
        if self.model is None:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(self.model_name)

    def index(self, chunks: List[dict], progress_callback=None):
        self.load_model()
        self.chunks = chunks
        texts = [c.get('content', '')[:512] for c in chunks]

        if progress_callback:
            progress_callback(0.5, f"编码 {len(texts)} chunks...")

        self.embeddings = self.model.encode(texts, show_progress_bar=True,
                                            convert_to_tensor=True, batch_size=64)

    def search(self, query: str, top_k: int = 20, doc_filter: str = None) -> Dict[int, float]:
        query_emb = self.model.encode([query], convert_to_tensor=True)
        scores = torch.mm(query_emb, self.embeddings.T).squeeze(0).cpu().numpy()

        # 应用文档过滤
        if doc_filter and doc_filter != "所有文档":
            real_doc_id = doc_filter.split(" (")[0]
            for i, chunk in enumerate(self.chunks):
                if chunk.get('doc_id') != real_doc_id:
                    scores[i] = -999

        top_idx = np.argsort(-scores)[:top_k]
        return {int(idx): float(scores[idx]) for idx in top_idx if scores[idx] > -999}


class MoRERetriever:
    """MoRE 融合检索器"""

    def __init__(self):
        self.bm25 = BM25Retriever()
        self.dense = DenseRetriever('all-MiniLM-L6-v2')
        self.weights = [0.4, 0.6]

    def index(self, chunks: List[dict], progress_callback=None):
        if progress_callback:
            progress_callback(0.1, "构建 BM25 索引...")
        self.bm25.index(chunks)

        if progress_callback:
            progress_callback(0.3, "构建 Dense 索引...")
        self.dense.index(chunks, progress_callback)

        self.chunks = chunks

    def normalize_scores(self, scores: Dict[int, float]) -> Dict[int, float]:
        if not scores:
            return {}
        vals = list(scores.values())
        min_v, max_v = min(vals), max(vals)
        r = max_v - min_v if max_v > min_v else 1.0
        return {k: (v - min_v) / r for k, v in scores.items()}

    def search(self, query: str, top_k: int = 10, doc_filter: str = None) -> List[Tuple[dict, float]]:
        bm25_scores = self.bm25.search(query, top_k * 3, doc_filter)
        dense_scores = self.dense.search(query, top_k * 3, doc_filter)

        bm25_norm = self.normalize_scores(bm25_scores)
        dense_norm = self.normalize_scores(dense_scores)

        all_ids = set(bm25_norm.keys()) | set(dense_norm.keys())
        fused = {}
        for idx in all_ids:
            score = (self.weights[0] * bm25_norm.get(idx, 0) +
                    self.weights[1] * dense_norm.get(idx, 0))
            fused[idx] = score

        sorted_results = sorted(fused.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return [(self.chunks[idx], score) for idx, score in sorted_results]


# ============================================================================
# 千问 VL (视觉语言模型)
# ============================================================================

class Qwen2VL:
    """Qwen2-VL 视觉语言模型 - 用于图像理解"""

    def __init__(self, model_path: str = None):
        if model_path is None:
            model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models', 'Qwen2-VL-7B-Instruct')
        self.model_path = model_path
        self.model = None
        self.processor = None

    def load(self, progress_callback=None):
        if self.model is not None:
            return

        if progress_callback:
            progress_callback(0.5, "加载 Qwen2-VL 视觉模型 (FP16模式)...")

        from transformers import Qwen2VLForConditionalGeneration, AutoProcessor

        # 直接加载模型（不使用量化，避免 bitsandbytes 依赖）
        self.model = Qwen2VLForConditionalGeneration.from_pretrained(
            self.model_path,
            torch_dtype=torch.float16,  # 使用 FP16 减少内存
            device_map="auto",
            trust_remote_code=True
        )
        self.processor = AutoProcessor.from_pretrained(self.model_path, trust_remote_code=True)
        logger.info("Qwen2-VL 加载完成 (FP16)")

    def understand_image(self, image: Image.Image, question: str) -> str:
        """理解图片内容并回答问题"""
        from qwen_vl_utils import process_vision_info

        # 构建多模态消息
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": question}
                ]
            }
        ]

        # 处理输入
        text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        image_inputs, video_inputs = process_vision_info(messages)

        inputs = self.processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt"
        ).to(self.model.device)

        # 生成
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=False
        )

        # 解码
        generated_ids = outputs[:, inputs.input_ids.shape[1]:]
        response = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return response


# ============================================================================
# 千问 LLM (文本模型)
# ============================================================================

class QwenLLM:
    def __init__(self, model_path: str = None):
        if model_path is None:
            model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models', 'Qwen2-7B-Instruct')
        self.model_path = model_path
        self.model = None
        self.tokenizer = None

    def load(self, progress_callback=None):
        if self.model is not None:
            return

        if progress_callback:
            progress_callback(0.7, "加载千问 7B 文本模型 (4bit量化)...")

        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, trust_remote_code=True)
        # 使用 4bit 量化加载，节省显存（约 4G vs FP16 的 14G）
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_quant_type="nf4",
        )
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            quantization_config=quantization_config,
            device_map="auto",
            trust_remote_code=True
        )
        logger.info("千问 7B 文本模型加载完成 (4bit量化)")

    def generate(self, prompt: str, max_tokens: int = 1024) -> str:
        messages = [{"role": "user", "content": prompt}]
        text = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

        inputs = self.tokenizer([text], return_tensors="pt").to(self.model.device)
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=max_tokens,
            do_sample=False,
            pad_token_id=self.tokenizer.eos_token_id
        )

        response = self.tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
        return response


# ============================================================================
# 远程模型客户端（连接 model_server.py）
# ============================================================================

class ModelServerClient:
    """模型服务器客户端 - 连接已启动的 model_server.py"""

    def __init__(self, server_url: str = "http://127.0.0.1:8100"):
        self.server_url = server_url
        self._connected = False

    def check_connection(self) -> bool:
        """检查服务器连接"""
        import requests
        try:
            resp = requests.get(f"{self.server_url}/health", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                self._connected = data.get("models_loaded", False)
                return self._connected
        except Exception as e:
            logger.warning(f"无法连接模型服务器: {e}")
        return False

    def is_connected(self) -> bool:
        return self._connected


class RemoteVLM:
    """远程 VLM - 通过 API 调用模型服务器"""

    def __init__(self, client: ModelServerClient):
        self.client = client
        self.model = True  # 标记为已加载（实际在服务器端）

    def load(self, progress_callback=None):
        if progress_callback:
            progress_callback(0.5, "连接远程 VLM 模型...")
        # 无需加载，模型在服务器端

    def understand_image(self, image: Image.Image, question: str) -> str:
        """通过 API 调用远程 VLM"""
        import requests
        import base64
        import io

        # 图片转 base64
        buffer = io.BytesIO()
        image.save(buffer, format='PNG')
        image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

        try:
            resp = requests.post(
                f"{self.client.server_url}/vlm/understand",
                json={"image_base64": image_base64, "question": question},
                timeout=120
            )
            if resp.status_code == 200:
                return resp.json().get("response", "")
            else:
                return f"VLM 调用失败: {resp.status_code}"
        except Exception as e:
            return f"VLM 调用错误: {e}"


class RemoteLLM:
    """远程 LLM - 通过 API 调用模型服务器"""

    def __init__(self, client: ModelServerClient):
        self.client = client
        self.model = True  # 标记为已加载

    def load(self, progress_callback=None):
        if progress_callback:
            progress_callback(0.7, "连接远程 LLM 模型...")
        # 无需加载，模型在服务器端

    def generate(self, prompt: str, max_tokens: int = 1024) -> str:
        """通过 API 调用远程 LLM"""
        import requests

        try:
            resp = requests.post(
                f"{self.client.server_url}/llm/generate",
                json={"prompt": prompt, "max_tokens": max_tokens},
                timeout=120
            )
            if resp.status_code == 200:
                return resp.json().get("response", "")
            else:
                return f"LLM 调用失败: {resp.status_code}"
        except Exception as e:
            return f"LLM 调用错误: {e}"


class RemoteImageMatcher:
    """远程图片匹配器 - 通过 API 调用 CLIP"""

    def __init__(self, client: ModelServerClient, cache_dir: str = './data/cache'):
        self.client = client
        self.model = True  # 标记为已加载
        self.image_embeddings = {}
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def load_model(self):
        pass  # 模型在服务器端

    def _get_cache_path(self, data_dir: Path) -> Path:
        import hashlib
        dir_hash = hashlib.md5(str(data_dir.resolve()).encode()).hexdigest()[:8]
        return self.cache_dir / f"image_embeddings_{dir_hash}.pkl"

    def _load_cache(self, cache_path: Path, images: List[dict]) -> bool:
        import pickle
        if not cache_path.exists():
            return False
        try:
            with open(cache_path, 'rb') as f:
                cached_data = pickle.load(f)
            if cached_data.get('n_images') != len(images):
                return False
            self.image_embeddings = cached_data.get('embeddings', {})
            logger.info(f"从缓存加载了 {len(self.image_embeddings)} 张图片的 embeddings")
            return True
        except Exception as e:
            logger.warning(f"加载缓存失败: {e}")
            return False

    def _save_cache(self, cache_path: Path, n_images: int):
        import pickle
        try:
            cached_data = {'n_images': n_images, 'embeddings': self.image_embeddings}
            with open(cache_path, 'wb') as f:
                pickle.dump(cached_data, f)
            logger.info(f"缓存已保存: {cache_path}")
        except Exception as e:
            logger.warning(f"保存缓存失败: {e}")

    def index_images(self, images: List[dict], data_dir: Path, progress_callback=None):
        """索引图片（通过远程 CLIP）"""
        import requests
        import base64

        data_dir_abs = data_dir.resolve()
        project_root = data_dir_abs.parent.parent if data_dir_abs.name == 'processed' else data_dir_abs.parent

        # 尝试加载缓存
        cache_path = self._get_cache_path(data_dir)
        if self._load_cache(cache_path, images):
            if progress_callback:
                progress_callback(1.0, f"从缓存加载了 {len(self.image_embeddings)} 张图片")
            return

        # 收集有效图片
        valid_images = []
        image_paths = []
        for img in images:
            img_rel_path = img.get('image_path', '')
            img_path = project_root / img_rel_path
            if img_path.exists():
                valid_images.append(img)
                image_paths.append(str(img_path))

        if not image_paths:
            return

        if progress_callback:
            progress_callback(0.2, f"准备 {len(image_paths)} 张图片...")

        # 批量编码（通过远程服务器）
        batch_size = 32
        all_embeddings = []

        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i:i+batch_size]
            images_base64 = []

            for path in batch_paths:
                with open(path, 'rb') as f:
                    images_base64.append(base64.b64encode(f.read()).decode('utf-8'))

            if progress_callback:
                progress_callback(0.2 + 0.7 * (i / len(image_paths)),
                                  f"编码图片 {i+1}-{min(i+batch_size, len(image_paths))}/{len(image_paths)}...")

            try:
                resp = requests.post(
                    f"{self.client.server_url}/clip/encode_batch",
                    json={"images_base64": images_base64},
                    timeout=300
                )
                if resp.status_code == 200:
                    batch_embeddings = resp.json().get("embeddings", [])
                    all_embeddings.extend(batch_embeddings)
                else:
                    logger.error(f"CLIP 编码失败: {resp.status_code}")
                    return
            except Exception as e:
                logger.error(f"CLIP 编码错误: {e}")
                return

        # 保存 embeddings
        for img, emb in zip(valid_images, all_embeddings):
            self.image_embeddings[img['image_id']] = {
                'embedding': np.array(emb),
                'info': img
            }

        self._save_cache(cache_path, len(images))
        logger.info(f"索引了 {len(self.image_embeddings)} 张图片")

    def find_similar(self, uploaded_image: Image.Image, top_k: int = 5) -> List[dict]:
        """查找相似图片"""
        import requests
        import base64
        import io

        if not self.image_embeddings:
            return []

        # 编码上传的图片
        buffer = io.BytesIO()
        uploaded_image.save(buffer, format='PNG')
        image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

        try:
            resp = requests.post(
                f"{self.client.server_url}/clip/encode",
                json={"image_base64": image_base64},
                timeout=30
            )
            if resp.status_code != 200:
                return []
            query_emb = np.array(resp.json().get("embedding", []))
        except Exception as e:
            logger.error(f"CLIP 编码错误: {e}")
            return []

        # 计算相似度
        results = []
        for img_id, data in self.image_embeddings.items():
            emb = data['embedding']
            similarity = np.dot(query_emb, emb) / (np.linalg.norm(query_emb) * np.linalg.norm(emb))
            results.append({
                'image_id': img_id,
                'similarity': float(similarity),
                'doc_id': data['info'].get('doc_id'),
                'doc_title': data['info'].get('doc_title'),
                'page': data['info'].get('page'),
                'image_path': data['info'].get('image_path')
            })

        results.sort(key=lambda x: x['similarity'], reverse=True)
        return results[:top_k]


def is_quality_chunk(content: str) -> bool:
    """判断 chunk 是否是有意义的文本（宽松过滤）"""
    if not content or len(content) < 30:
        return False

    # 检查是否包含有意义的技术词汇
    tech_keywords = ['maintenance', 'repair', 'valve', 'pump', 'pressure', 'hydraulic',
                     'filter', 'warning', 'caution', 'inspect', 'replace', 'install',
                     'remove', 'check', 'system', 'component', 'unit', 'assembly']
    content_lower = content.lower()
    has_tech_term = any(kw in content_lower for kw in tech_keywords)

    # 如果包含技术词汇，直接通过
    if has_tech_term:
        return True

    # 计算字母比例（宽松标准）
    letters = sum(c.isalpha() for c in content)
    if len(content) > 0:
        letter_ratio = letters / len(content)
        if letter_ratio < 0.2:  # 字母少于20%才过滤
            return False

    return True


# ============================================================================
# PDF 问答系统
# ============================================================================

class PDFChatSystem:
    def __init__(self, single_file: str = None, fast_mode: bool = False,
                 client_mode: bool = False, server_url: str = "http://127.0.0.1:8100"):
        self.kb = PDFKnowledgeBase(single_file=single_file)
        self.retriever = MoRERetriever()
        self.initialized = False
        self.fast_mode = fast_mode  # 快速模式：跳过图片索引
        self.client_mode = client_mode  # 客户端模式：连接远程模型服务器

        if client_mode:
            # 客户端模式：使用远程模型
            self.model_client = ModelServerClient(server_url)
            self.image_matcher = RemoteImageMatcher(self.model_client)
            self.vlm = RemoteVLM(self.model_client)
            self.llm = RemoteLLM(self.model_client)
        else:
            # 本地模式：加载本地模型
            self.model_client = None
            self.image_matcher = ImageMatcher()
            self.vlm = Qwen2VL()  # 视觉语言模型
            self.llm = QwenLLM()  # 文本模型

    def initialize(self, progress=gr.Progress()):
        if self.initialized:
            return "系统已初始化", self.kb.get_doc_list()

        try:
            print("[初始化] 开始...")

            # 客户端模式：先检查服务器连接
            if self.client_mode:
                progress(0.02, "检查模型服务器连接...")
                print("[初始化] 检查模型服务器连接...")
                if not self.model_client.check_connection():
                    return "❌ 无法连接模型服务器！请先启动: python demo/model_server.py", ["所有文档"]
                print("[初始化] 模型服务器已连接")

            progress(0.05, "加载 PDF 数据...")
            print("[初始化] 加载 PDF 数据...")
            n_docs, n_chunks, n_images = self.kb.load_all(lambda p, m: progress(0.05 + p * 0.1, m))
            print(f"[初始化] PDF 数据加载完成: {n_docs} 文档, {n_chunks} chunks, {n_images} 图片")

            progress(0.15, "构建 MoRE 检索索引...")
            print("[初始化] 构建 MoRE 检索索引...")
            self.retriever.index(self.kb.chunks, lambda p, m: progress(0.15 + p * 0.2, m))
            print("[初始化] MoRE 检索索引完成")

            progress(0.35, "跳过图片索引（页面不展示图片）")
            print("[初始化] 跳过图片索引（页面不展示图片）")

            if self.client_mode:
                # 客户端模式：模型已在服务器加载，只需连接
                progress(0.45, "连接远程模型...")
                print("[初始化] 客户端模式：连接远程模型...")
                self.vlm.load(lambda p, m: progress(0.45 + p * 0.1, m))
                self.llm.load(lambda p, m: progress(0.55 + p * 0.1, m))
                print("[初始化] 远程模型连接完成")
            else:
                # 本地模式：加载模型
                progress(0.45, "加载 Qwen2-VL 视觉模型...")
                print("[初始化] 加载 Qwen2-VL 视觉模型...")
                self.vlm.load(lambda p, m: progress(0.45 + p * 0.25, m))
                print("[初始化] Qwen2-VL 视觉模型加载完成")

                progress(0.7, "加载千问 7B 文本模型...")
                print("[初始化] 加载千问 7B 文本模型...")
                self.llm.load(lambda p, m: progress(0.6 + p * 0.35, m))
                print("[初始化] 千问 7B 文本模型加载完成")

            self.initialized = True
            progress(1.0)
            print("[初始化] 全部完成!")
        except Exception as e:
            print(f"[初始化] 错误: {e}")
            import traceback
            traceback.print_exc()
            raise

        mode_info = "🌐 客户端模式（远程模型）" if self.client_mode else "💻 本地模式"
        status = f"""✅ 初始化完成！

{mode_info}

📚 **{n_docs}** 个 PDF 文档
📝 **{n_chunks}** 个文本块
🖼️ **{n_images}** 张图片
📊 **{len(self.kb.tables)}** 个表格

🔍 MoRE 检索器就绪
🤖 千问 7B 就绪"""

        return status, self.kb.get_doc_list()

    def find_image_source(self, image: Image.Image) -> str:
        """查找上传图片的来源 - 只返回最佳匹配"""
        if image is None:
            return "请上传图片"

        if not self.initialized:
            return "请先初始化系统"

        results = self.image_matcher.find_similar(image, top_k=1)

        if not results:
            return "未找到匹配的图片，可能图片库中没有索引"

        # 只取最佳匹配
        best = results[0]
        similarity_pct = best['similarity'] * 100

        response = f"""## 🖼️ 图片匹配结果

### ✅ 找到匹配！

| 项目 | 信息 |
|------|------|
| **文档** | `{best['doc_id']}` |
| **页码** | **第 {best['page']} 页** |
| **匹配度** | {similarity_pct:.1f}% |

---

📍 **该图片位于 第 {best['page']} 页**
"""

        return response

    def get_tables(self, doc_select: str, num_tables: int) -> str:
        """获取指定文档的表格"""
        if not self.initialized:
            return "请先初始化系统"

        tables = self.kb.get_tables_by_doc(doc_select, int(num_tables))

        if not tables:
            return f"在 {doc_select} 中未找到表格内容"

        response = f"## 📊 表格内容 ({doc_select})\n\n"
        for i, t in enumerate(tables, 1):
            response += f"### 表格 {i}\n"
            response += f"**文档**: {t['doc_id']}\n"
            response += f"**页码**: {t['page']}\n"
            response += f"**内容**:\n```\n{t['content']}\n```\n\n---\n\n"

        return response

    def chat(self, message: dict, history: List, doc_filter: str) -> Tuple[str, List]:
        """多模态聊天接口 - 支持文本和图片，返回 (消息框, 聊天历史)"""
        if not self.initialized:
            history.append({"role": "user", "content": "请先初始化系统"})
            history.append({"role": "assistant", "content": "请先点击'初始化系统'按钮"})
            return None, history

        # 解析消息内容
        text_query = ""
        uploaded_image = None

        if isinstance(message, dict):
            text_query = message.get("text", "").strip()
            files = message.get("files", [])
            if files:
                # 获取上传的图片
                from PIL import Image
                uploaded_image = Image.open(files[0]).convert('RGB')
        elif isinstance(message, str):
            text_query = message.strip()

        if not text_query and not uploaded_image:
            return None, history

        # 构建用户消息显示
        user_content = []
        if uploaded_image:
            user_content.append({"type": "image", "path": message.get("files", [None])[0]})
        if text_query:
            user_content.append({"type": "text", "text": text_query})

        if len(user_content) == 1 and user_content[0].get("type") == "text":
            history.append({"role": "user", "content": text_query})
        else:
            history.append({"role": "user", "content": user_content})

        # 如果有图片，先进行图片识别
        if uploaded_image:
            image_result = self._process_image(uploaded_image, text_query)
            history.append({"role": "assistant", "content": image_result})
            return None, history

        # 检测特殊查询：表格查询
        if "表格" in text_query:
            table_result = self._process_table_query(text_query, doc_filter)
            history.append({"role": "assistant", "content": table_result})
            return None, history

        # 普通文本检索问答
        text_response, image_paths = self._text_qa(text_query, doc_filter)

        # 添加文本响应
        history.append({"role": "assistant", "content": text_response})

        return None, history

    def _process_image(self, image: Image.Image, query: str = "") -> str:
        """处理图片查询 - Qwen2-VL 视觉理解 + MoRE 跨文档检索"""
        import re

        response_parts = []

        # Step 1: 使用 Qwen2-VL 理解图片内容
        response_parts.append("## 🔍 Step 1: 视觉理解 (Qwen2-VL)\n")

        # 构建视觉理解问题
        if query:
            # 提取用户关心的编号
            component_match = re.search(r'(\d+)\s*号', query)
            if component_match:
                component_num = component_match.group(1)
                vlm_question = f"""请仔细观察这张技术图纸/设备图片：
1. 找到图中标注的 {component_num} 号位置
2. 识别 {component_num} 号对应的是什么组件/部件（根据图例或标注）
3. 描述该组件在图中的位置和外观特征

请直接回答 {component_num} 号是什么组件。"""
            else:
                vlm_question = f"""请仔细观察这张技术图纸/设备图片：
1. 识别图中的主要组件和标注
2. 回答用户的问题：{query}

请详细描述你在图中看到的内容。"""
        else:
            vlm_question = """请仔细观察这张技术图纸/设备图片：
1. 列出图中所有标注的组件编号和对应名称
2. 描述这是什么类型的设备/系统
3. 识别图中的关键部件"""

        # Qwen2-VL 视觉理解
        try:
            vlm_response = self.vlm.understand_image(image, vlm_question)
            response_parts.append(f"**视觉识别结果：**\n\n{vlm_response}\n")
        except Exception as e:
            logger.error(f"VLM 错误: {e}")
            response_parts.append(f"⚠️ 视觉模型处理出错: {str(e)[:100]}\n")
            vlm_response = ""

        # Step 2: 图片来源匹配（可选）
        match_results = self.image_matcher.find_similar(image, top_k=1)
        if match_results:
            best = match_results[0]
            response_parts.append(f"\n## 📍 图片来源匹配\n")
            response_parts.append(f"- **文档**: `{best['doc_id']}`\n")
            response_parts.append(f"- **页码**: 第 {best['page']} 页\n")
            response_parts.append(f"- **匹配度**: {best['similarity']*100:.1f}%\n")

        # Step 3: MoRE 跨文档检索
        if query or vlm_response:
            response_parts.append("\n## 🔎 Step 2: MoRE 跨文档检索\n")

            # 从 VLM 响应中提取组件名称作为检索关键词
            search_terms = []

            # 添加用户原始查询
            if query:
                search_terms.append(query)

            # 从 VLM 响应提取关键词（组件名称）
            if vlm_response:
                # 提取英文组件名（如 BOOST PRESSURE GAUGE）
                eng_components = re.findall(r'[A-Z][A-Z\s]{3,}(?:GAUGE|VALVE|METER|INDICATOR|SWITCH|PUMP|MOTOR|LIGHT|BUTTON|PORT)', vlm_response)
                search_terms.extend(eng_components[:3])

                # 提取中文组件名
                cn_components = re.findall(r'[\u4e00-\u9fa5]{2,}(?:表|阀|计|器|泵|灯|开关|按钮)', vlm_response)
                search_terms.extend(cn_components[:3])

            # 去重
            search_terms = list(set(search_terms))

            # 翻译中文关键词为英文（因为文档是英文的）
            translated_terms = []
            for term in search_terms:
                translated = self._translate_to_english(term)
                translated_terms.append(translated)
                if translated != term:
                    translated_terms.append(term)  # 保留原始词

            search_terms = list(set(translated_terms))

            if search_terms:
                response_parts.append(f"**检索关键词**: {', '.join(search_terms)}\n\n")

            # MoRE 跨文档检索
            all_results = []
            for term in search_terms:
                raw_results = self.retriever.search(term, top_k=8, doc_filter=None)
                for chunk, score in raw_results:
                    if is_quality_chunk(chunk.get('content', '')):
                        chunk_id = chunk.get('chunk_id')
                        if not any(r[0].get('chunk_id') == chunk_id for r in all_results):
                            all_results.append((chunk, score))

            all_results.sort(key=lambda x: x[1], reverse=True)
            results_to_use = all_results[:6]

            if results_to_use:
                # 构建上下文
                context_parts = []
                doc_sources = set()
                for i, (chunk, score) in enumerate(results_to_use, 1):
                    doc_id = chunk.get('doc_id', 'unknown')
                    chunk_id = chunk.get('chunk_id', 'unknown')
                    page = chunk.get('page', 'N/A')
                    content = chunk.get('content', '')
                    context_parts.append(f"[来源 {i}: {doc_id}, 页{page}]\n{content}")
                    doc_sources.add(doc_id)

                context = "\n\n---\n\n".join(context_parts)
                response_parts.append(f"**检索到 {len(results_to_use)} 条相关内容，来自 {len(doc_sources)} 个文档**\n")

                # Step 4: LLM 综合回答
                response_parts.append("\n## 💬 Step 3: 综合回答\n")

                prompt = f"""你是一个专业的技术文档助手。根据以下信息综合回答用户问题。

## 视觉识别结果 (Qwen2-VL)
{vlm_response}

## 用户问题
{query if query else "请介绍图中的组件"}

## 跨文档检索结果 (MoRE，来自 {len(doc_sources)} 个文档)

{context}

## 回答要求
1. 结合视觉识别和文档检索的信息
2. 明确说明组件名称、功能、位置
3. 如果问到维修/故障，提供相关建议
4. **关键词加粗**
5. 引用来源：[来源 X]

## 综合回答"""

                answer = self.llm.generate(prompt, max_tokens=512)
                response_parts.append(answer)

                # 添加来源详情
                response_parts.append("\n\n---\n## 📚 检索来源详情\n\n")
                for i, (chunk, score) in enumerate(results_to_use, 1):
                    chunk_id = chunk.get('chunk_id', 'unknown')
                    doc_id = chunk.get('doc_id', 'unknown')
                    page = chunk.get('page', 'N/A')
                    content = chunk.get('content', '').replace('\n', ' ')
                    response_parts.append(f"**[来源 {i}]** `{chunk_id}` | {doc_id} 页{page}\n")
                    response_parts.append(f"> {content}\n\n")
            else:
                response_parts.append("未找到相关文档内容。\n")

        return "".join(response_parts)

    def _process_table_query(self, query: str, doc_filter: str) -> str:
        """处理表格查询"""
        # 提取数量
        import re
        num_match = re.search(r'(\d+)\s*个?表格', query)
        limit = int(num_match.group(1)) if num_match else 3

        tables = self.kb.get_tables_by_doc(doc_filter, limit)

        if not tables:
            return f"在 {doc_filter} 中未找到表格内容"

        response = f"## 📊 表格内容 ({doc_filter})\n\n"
        for i, t in enumerate(tables, 1):
            response += f"### 表格 {i}\n"
            response += f"**文档**: {t['doc_id']}\n"
            response += f"**页码**: {t['page']}\n"
            response += f"**内容**:\n```\n{t['content']}\n```\n\n---\n\n"

        return response

    def _find_complete_table(self, query: str, query_en: str, doc_filter: str) -> Optional[str]:
        """
        查找完整的表格内容 - 用于表格查询
        直接返回完整表格，不经过 LLM 摘要
        """
        import re

        # 从所有 chunks 中查找 complete_table 类型的 chunks
        complete_table_chunks = []
        for chunk in self.kb.chunks:
            chunk_id = chunk.get('chunk_id', '')
            if 'complete_table' in chunk_id:
                complete_table_chunks.append(chunk)

        if not complete_table_chunks:
            return None

        # 根据查询匹配最相关的表格
        query_upper = query.upper()
        query_en_upper = query_en.upper()

        # 提取查询中的关键标识符（如 F-2, APPENDIX F 等）
        table_id_match = re.search(r'([A-Z])-?(\d+)', query_upper)
        appendix_match = re.search(r'APPENDIX\s*([A-Z])', query_upper)

        best_match = None
        best_score = 0

        for chunk in complete_table_chunks:
            content = chunk.get('content', '')
            chunk_id = chunk.get('chunk_id', '')
            content_upper = content[:2000].upper()

            score = 0

            # 关键：检查是否包含实际表格数据（ITEM NO. 列）
            has_item_no = 'ITEM NO' in content_upper or 'ITEM NO.' in content_upper
            if has_item_no:
                score += 100  # 包含实际数据的表格优先

            # 检查是否是 list_ 类型（包含实际数据）
            if 'list_' in chunk_id.lower():
                score += 50

            # 检查 chunk_id 匹配
            if table_id_match:
                table_letter = table_id_match.group(1)
                if f'list_{table_letter}' in chunk_id.lower():
                    score += 80  # list_F 比 appendix_F 更优先
                elif f'_{table_letter}' in chunk_id:
                    score += 30

            if appendix_match:
                appendix_letter = appendix_match.group(1)
                if f'list_{appendix_letter}' in chunk_id.lower():
                    score += 80
                elif f'appendix_{appendix_letter}' in chunk_id.lower():
                    score += 30

            # 检查内容匹配 - 优先匹配操作指南类内容
            if 'HOW TO USE' in query_upper:
                if 'HOW TO USE TORQUE TABLE' in content_upper:
                    score += 200  # 精确匹配操作指南标题
                elif 'HOW TO USE' in content_upper:
                    score += 100  # 匹配操作指南类型
                # 降低零件清单的优先级
                if 'MANDATORY REPLACEMENT PARTS' in content_upper or 'PARTS LIST' in content_upper:
                    score -= 50  # 零件清单不是操作指南

            # 检查内容匹配 - 查找完整标题
            if 'MANDATORY REPLACEMENT PARTS' in query_upper:
                if 'F-2 MANDATORY REPLACEMENT PARTS LIST' in content_upper:
                    score += 150  # 精确匹配标题

            # 检查内容匹配
            for keyword in ['MANDATORY', 'REPLACEMENT', 'PARTS', 'LIST']:
                if keyword in query_upper and keyword in content_upper:
                    score += 5

            # 特殊处理：TORQUE TABLE 查询应该匹配使用说明，不是零件清单
            if 'TORQUE' in query_upper and 'TABLE' in query_upper:
                if 'HOW TO USE TORQUE TABLE' in content_upper:
                    score += 200  # 扭矩表使用说明优先级最高
                elif 'TORQUE LIMITS' in content_upper:
                    score += 150  # 扭矩限制表次之
                elif 'E-1' in content_upper or 'E-2' in content_upper:
                    score += 100  # E系列附录（通常是扭矩相关）
                # 大幅降低零件清单的优先级
                if 'MANDATORY REPLACEMENT PARTS' in content_upper or 'PARTS LIST' in content_upper:
                    score -= 100  # 零件清单与扭矩表使用无关

            # 内容长度加分（完整表格通常更长）
            if len(content) > 10000:
                score += 50
            elif len(content) > 5000:
                score += 30
            elif len(content) > 2000:
                score += 10

            # 文档过滤
            if doc_filter and doc_filter != "所有文档":
                real_doc_id = doc_filter.split(" (")[0]
                if chunk.get('doc_id') != real_doc_id:
                    score = 0  # 不匹配的文档

            if score > best_score:
                best_score = score
                best_match = chunk

        if best_match and best_score >= 20:
            content = best_match.get('content', '')
            chunk_id = best_match.get('chunk_id', '')
            doc_id = best_match.get('doc_id', '')
            page = best_match.get('page', 'N/A')

            # 统计表格条目数
            items = re.findall(r'^\s*(\d+)\s+\w', content, re.MULTILINE)
            item_count = len(items)

            response = f"""## 📊 完整表格内容

**查询**: {query}
**文档**: `{doc_id}`
**页码**: 第 {page} 页
**条目数**: {item_count} 个

---

```
{content}
```

---

**说明**: 以上是从 PDF 文档中提取的完整表格内容。
"""
            return response

        return None

    def _translate_to_english(self, text: str) -> str:
        """将中文查询转换为英文检索关键词"""
        import re
        if not re.search(r'[\u4e00-\u9fa5]', text):
            return text  # 已经是英文

        prompt = f"""Translate the Chinese query below to English search keywords.
Context: technical maintenance manuals (hydraulic, pumps, valves, fuel systems).
Note: 高压=high pressure, 液压=hydraulic, 阀门=valve, 泵=pump, 扭矩=torque, 泄漏=leak.

Rules:
- Output ONLY keywords from the query (3-6 words max)
- Do NOT include domain context words
- No sentences, no punctuation

Chinese: {text}
Keywords:"""
        translation = self.llm.generate(prompt, max_tokens=50)
        # 清理输出，只保留关键词
        keywords = translation.strip().replace(',', ' ').replace('.', ' ').replace('_', ' ')
        return keywords

    def _text_qa(self, query: str, doc_filter: str) -> Tuple[str, List[str]]:
        """文本问答 - 返回 (文本回答, 相关图片路径列表)"""
        # 翻译中文查询为英文（因为文档是英文的）
        query_en = self._translate_to_english(query)

        response_parts = []
        if query_en != query:
            response_parts.append(f"🔄 **查询翻译**: {query} → {query_en}\n\n")

        # 检测是否是表格/清单查询 - 优先使用完整表格检索
        table_keywords = ['list', 'table', 'parts', 'appendix', 'mandatory', 'replacement',
                          '清单', '表格', '附录', '零件']
        query_lower = query.lower() + ' ' + query_en.lower()
        is_table_query = any(kw in query_lower for kw in table_keywords)

        if is_table_query:
            # 尝试直接查找完整表格
            table_result = self._find_complete_table(query, query_en, doc_filter)
            if table_result:
                return "".join(response_parts) + table_result, []

        # 检索（使用英文查询）- 增加检索数量
        raw_results = self.retriever.search(query_en, top_k=25, doc_filter=doc_filter)

        # 过滤低质量 chunk，取前8个最相关的结果（增加数量以获取更完整内容）
        results = []
        for chunk, score in raw_results:
            content = chunk.get('content', '')
            if is_quality_chunk(content):
                results.append((chunk, score))
            if len(results) >= 8:
                break

        if not results:
            return "".join(response_parts) + "未找到相关内容", []

        # 检测是否是技术操作类查询（包含步骤、警告等）
        procedure_keywords = ['removal', 'installation', 'procedure', 'step', 'how to',
                              '拆卸', '安装', '步骤', '操作', '流程']
        is_procedure_query = any(kw in query_lower for kw in procedure_keywords)

        # 构建上下文
        context_parts = []
        for i, (chunk, score) in enumerate(results, 1):
            chunk_id = chunk.get('chunk_id', 'unknown')
            page = chunk.get('page', 'N/A')
            content = chunk.get('content', '')
            context_parts.append(f"[来源 {i}: {chunk_id}, 页{page}]\n{content}")

        context = "\n\n".join(context_parts)

        prompt = f"""你是一个专业的技术文档助手。请根据参考资料直接整理回答问题。

规则：
- 参考资料中的原文就是答案，直接整理输出。
- 绝对不要说"参考资料中没有提供"、"无"、"未提及"等类似表述。如果某项内容在参考资料中没有明确出现，就跳过该项，不要输出。
- 不要重复输出用户的问题标题。
- 用中文回答，专业术语保留英文原文。

参考资料：

{context}

用户问题：{query}

请按以下格式整理输出（没有的项直接跳过，不要写"无"）：

**概述**：简要说明该内容是什么

**工具/材料清单**：
- 列出所有工具和材料

**前提条件**：列出执行前需要完成的工作

**警告(WARNING)**：完整输出警告内容

**注意(NOTE/CAUTION)**：完整输出注意事项

**操作步骤**：
1. 步骤内容
2. 步骤内容

回答："""

        response = self.llm.generate(prompt, max_tokens=4096)

        # 添加来源详情
        sources = "\n\n---\n## 📚 检索来源详情\n\n"

        # 收集所有涉及的页码，用于查找相关图片
        involved_pages = set()
        involved_doc_ids = set()

        for i, (chunk, score) in enumerate(results, 1):
            chunk_id = chunk.get('chunk_id', 'unknown')
            doc_id = chunk.get('doc_id', 'unknown')
            page = chunk.get('page', 'N/A')
            end_page = chunk.get('end_page', page)
            content = chunk.get('content', '')
            section_title = chunk.get('section_title', '')

            involved_doc_ids.add(doc_id)
            if isinstance(page, int):
                involved_pages.add(page)
                if isinstance(end_page, int):
                    for p in range(page, end_page + 1):
                        involved_pages.add(p)

            sources += f"**[来源 {i}]** `{chunk_id}`\n"
            sources += f"- 📄 文档: {doc_id}\n"
            sources += f"- 📑 页码: {page}"
            if end_page and end_page != page:
                sources += f"-{end_page}"
            sources += "\n"
            if section_title:
                sources += f"- 📌 章节: {section_title}\n"
            # 检测内容类型 - 表格或技术操作步骤显示完整
            content_upper = content[:500].upper()
            is_table = len(content) > 2000 or 'LIST' in content_upper or 'TABLE' in content_upper or 'PARTS' in content_upper
            is_procedure = 'WARNING' in content_upper or 'CAUTION' in content_upper or 'NOTE' in content_upper or 'REMOVAL' in content_upper or 'INSTALLATION' in content_upper

            if is_table or is_procedure:
                # 表格或技术操作内容显示完整
                content_type = "完整表格" if is_table else "技术操作步骤"
                sources += f"- 📝 原文（{content_type}）:\n```\n{content}\n```\n\n"
            else:
                # 普通内容截断预览
                content_preview = content[:1500] if len(content) > 1500 else content
                sources += f"- 📝 原文:\n> {content_preview}\n\n"

        text_response = "".join(response_parts) + response + sources
        return text_response, []


# ============================================================================
# Gradio 界面
# ============================================================================

def create_demo(single_file: str = None, fast_mode: bool = False,
                client_mode: bool = False, server_url: str = "http://127.0.0.1:8100"):
    system = PDFChatSystem(single_file=single_file, fast_mode=fast_mode,
                           client_mode=client_mode, server_url=server_url)

    mode_text = "🌐 客户端模式（连接远程模型服务器）" if client_mode else "💻 本地模式"

    with gr.Blocks(title="PDF RAG 智能问答", theme=gr.themes.Soft()) as demo:
        gr.Markdown(f"""
# 📚 PDF RAG 智能问答系统

基于 **MoRE 检索** + **千问 7B** 的多模态文档问答系统

**支持功能**：💬 文本问答 | 🖼️ 图片识别 | 📊 表格查询

**运行模式**：{mode_text}

---
""")

        with gr.Row():
            init_btn = gr.Button("🚀 初始化系统", variant="primary", scale=1)
            init_status = gr.Markdown("点击初始化加载所有 PDF 和模型")

        doc_dropdown = gr.Dropdown(
            choices=["所有文档"],
            value="所有文档",
            label="📁 选择文档范围",
            interactive=True
        )

        gr.Markdown("---")

        with gr.Row():
            # 多模态聊天界面 - 占满整个宽度
            chatbot = gr.Chatbot(
                label="智能问答",
                height=550,
                buttons=["copy", "copy_all"]
            )

        # 多模态输入框 - 支持文本和图片
        msg = gr.MultimodalTextbox(
            placeholder="输入问题或上传图片...\n示例: 14号是什么？/ 给我3个表格 / 上传图片查找来源",
            show_label=False,
            file_types=["image"],
            file_count="single"
        )

        with gr.Row():
            clear_btn = gr.Button("🗑️ 清空对话")

        gr.Markdown("""
### 💡 使用提示
- **文本问答**: 直接输入问题，如 "14号是什么组件？"
- **图片识别**: 点击📎上传图片，系统会找到图片来源页码
- **图片+问题**: 上传图片同时输入问题，如上传图片后问 "这是什么部件？"
- **表格查询**: 输入 "给我3个表格" 或 "显示所有表格"
""")

        # 事件绑定
        def on_init():
            status, doc_list = system.initialize()
            return status, gr.update(choices=doc_list)

        init_btn.click(
            on_init,
            outputs=[init_status, doc_dropdown]
        )

        msg.submit(
            system.chat,
            inputs=[msg, chatbot, doc_dropdown],
            outputs=[msg, chatbot]
        )

        clear_btn.click(lambda: [], outputs=[chatbot])

    return demo


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='PDF RAG 智能问答系统')
    parser.add_argument('--single-file', '-f', type=str, default=None,
                        help='只加载单个 PDF 文件 (JSON 路径)')
    parser.add_argument('--port', '-p', type=int, default=7863, help='服务端口')
    parser.add_argument('--fast', action='store_true',
                        help='快速模式：跳过图片索引，加速启动')
    parser.add_argument('--text-only', action='store_true',
                        help='纯文本模式：跳过视觉模型，只加载文本模型')
    parser.add_argument('--client', '-c', action='store_true',
                        help='客户端模式：连接远程模型服务器（需先启动 model_server.py）')
    parser.add_argument('--server-url', type=str, default='http://127.0.0.1:8100',
                        help='模型服务器地址 (默认 http://127.0.0.1:8100)')
    args = parser.parse_args()

    print("PDF RAG 智能问答系统 v2")
    print("=" * 40)
    if args.client:
        print(f"🌐 客户端模式: 连接 {args.server_url}")
        print("   确保已启动: python demo/model_server.py")
    else:
        print("💻 本地模式: 将加载本地模型")
    if args.single_file:
        print(f"单文件模式: {args.single_file}")
    if args.fast:
        print("⚡ 快速模式: 跳过图片索引")
    print("=" * 40)

    demo = create_demo(single_file=args.single_file, fast_mode=args.fast,
                       client_mode=args.client, server_url=args.server_url)
    demo.launch(
        server_name="0.0.0.0",
        server_port=args.port,
        share=False,  # 关闭公共链接，避免网络问题
        show_error=True,
        inbrowser=False  # 不自动打开浏览器
    )
