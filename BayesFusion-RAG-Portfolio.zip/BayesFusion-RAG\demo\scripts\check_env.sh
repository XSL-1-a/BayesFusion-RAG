#!/bin/bash
echo "=========================================="
echo "  HEA-MRAG Environment Check"
echo "=========================================="
echo ""
echo "System Info:"
echo "  OS: $(uname -s)"
echo "  Kernel: $(uname -r)"
echo ""
echo "Python:"
python3 --version
echo ""
echo "GPU Status:"
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
else
    echo "  No NVIDIA GPU detected"
fi
echo ""
echo "Environment check complete."
