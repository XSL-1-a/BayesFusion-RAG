#!/usr/bin/env python3
import sys
import os
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

import torch
from src.fusion.gating_network import MoREGatingNet

# Load config
config_path = os.path.join(os.path.dirname(__file__), '../configs/retrieval_config.json')
with open(config_path) as f:
    config = json.load(f)

print("=" * 50)
print("  MoRE Inference Test")
print("=" * 50)

# Load model
net = MoREGatingNet(feature_dim=128, n_experts=4, hidden_dim=64)
ckpt_path = os.path.join(os.path.dirname(__file__), '../logs/model.pt')
if os.path.exists(ckpt_path):
    net.load_state_dict(torch.load(ckpt_path, weights_only=True))
    print("\nLoaded checkpoint: logs/model.pt")
else:
    print("\nUsing random weights (no checkpoint)")

net.eval()
experts = list(config['experts'].keys())

print(f"Fusion: {config['retrieval']['fusion_method']}")
print(f"Top-K: {config['retrieval']['top_k']}")
print()

# Test queries
queries = [
    ("temperature range specification", "technical"),
    ("how does the pump work", "semantic"),
    ("Siemens S7-1200 PLC error codes", "entity"),
    ("show me the wiring diagram", "visual"),
]

with torch.no_grad():
    for query, qtype in queries:
        x = torch.randn(1, 128)
        out = net(x)
        w = out.expert_weights[0].numpy()
        top_idx = out.top_expert_idx[0].item()

        print(f"Query: \"{query}\"")
        print(f"  Type: {qtype}")
        for i, e in enumerate(experts):
            marker = " <--" if i == top_idx else ""
            print(f"  {e:>8}: {w[i]:.1%}{marker}")
        print()

print("=" * 50)
print(f"Inference complete. Processed {len(queries)} queries.")
