#!/usr/bin/env python3
"""
模型服务器 - 预加载模型，常驻内存
===================================
先启动此服务，模型只加载一次。
后续 app_pdf_chat.py 直接连接使用，无需重新加载。

完全离线运行，所有通信都在 localhost。

用法:
    1. 先启动模型服务: python demo/model_server.py
    2. 再启动 Web 应用: python demo/app_pdf_chat.py --client
"""

import os
import sys

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
# 离线模式：绕过代理，确保本地通信正常
os.environ.setdefault('no_proxy', '127.0.0.1,localhost')
# 完全离线模式：不检查 HuggingFace 更新，直接使用本地缓存
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'

# 预加载 cuDNN
def preload_cudnn():
    import ctypes
    venv_path = sys.prefix
    cudnn_lib_dir = os.path.join(venv_path, 'lib/python3.12/site-packages/nvidia/cudnn/lib')
    if not os.path.exists(cudnn_lib_dir):
        return
    cudnn_libs = [
        'libcudnn.so.9', 'libcudnn_ops.so.9', 'libcudnn_graph.so.9',
        'libcudnn_cnn.so.9', 'libcudnn_adv.so.9', 'libcudnn_heuristic.so.9',
        'libcudnn_engines_precompiled.so.9', 'libcudnn_engines_runtime_compiled.so.9',
    ]
    for lib_name in cudnn_libs:
        lib_path = os.path.join(cudnn_lib_dir, lib_name)
        if os.path.exists(lib_path):
            try:
                ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
            except OSError:
                pass

preload_cudnn()

import json
import torch
import logging
from pathlib import Path
from typing import Optional
from PIL import Image
import base64
import io

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ============================================================================
# 模型加载器（单例）
# ============================================================================

class ModelManager:
    """模型管理器 - 单例模式，保证模型只加载一次"""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self.vlm_model = None
        self.vlm_processor = None
        self.llm_model = None
        self.llm_tokenizer = None
        self.clip_model = None
        self._initialized = True

    def load_all(self,
                 vlm_path: str = "models/Qwen2-VL-7B-Instruct",
                 llm_path: str = "models/Qwen2.5-7B-Instruct"):
        """加载所有模型"""
        print("=" * 60)
        print("开始加载模型（只需加载一次）")
        print("=" * 60)

        self._load_clip()
        self._load_vlm(vlm_path)
        self._load_llm(llm_path)

        print("=" * 60)
        print("所有模型加载完成！服务就绪。")
        print("=" * 60)

    def _load_clip(self):
        """加载 CLIP 模型（用于图片匹配）"""
        if self.clip_model is not None:
            return

        print("[1/3] 加载 CLIP 模型...")
        from sentence_transformers import SentenceTransformer
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.clip_model = SentenceTransformer('clip-ViT-B-32', device=device)
        print(f"      CLIP 加载完成 (device: {device})")

    def _load_vlm(self, model_path: str):
        """加载 Qwen2-VL 视觉模型"""
        if self.vlm_model is not None:
            return

        print("[2/3] 加载 Qwen2-VL 视觉模型 (4bit量化)...")
        from transformers import Qwen2VLForConditionalGeneration, AutoProcessor, BitsAndBytesConfig

        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4"
        )

        self.vlm_model = Qwen2VLForConditionalGeneration.from_pretrained(
            model_path,
            quantization_config=quantization_config,
            device_map="auto",
            trust_remote_code=True
        )
        self.vlm_processor = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
        print("      Qwen2-VL 加载完成")

    def _load_llm(self, model_path: str):
        """加载千问文本模型"""
        if self.llm_model is not None:
            return

        print("[3/3] 加载千问 7B 文本模型 (4bit量化)...")
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4"
        )

        self.llm_tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        self.llm_model = AutoModelForCausalLM.from_pretrained(
            model_path,
            quantization_config=quantization_config,
            device_map="auto",
            trust_remote_code=True
        )
        print("      千问 7B 加载完成")

    def is_loaded(self) -> bool:
        """检查模型是否已加载"""
        return (self.vlm_model is not None and
                self.llm_model is not None and
                self.clip_model is not None)

    # ========== 推理方法 ==========

    def clip_encode_image(self, image_base64: str) -> list:
        """CLIP 编码图片"""
        image_data = base64.b64decode(image_base64)
        image = Image.open(io.BytesIO(image_data)).convert('RGB')
        embedding = self.clip_model.encode([image])[0]
        return embedding.tolist()

    def clip_encode_images_batch(self, images_base64: list) -> list:
        """CLIP 批量编码图片"""
        images = []
        for img_b64 in images_base64:
            image_data = base64.b64decode(img_b64)
            images.append(Image.open(io.BytesIO(image_data)).convert('RGB'))
        embeddings = self.clip_model.encode(images, batch_size=64)
        return [emb.tolist() for emb in embeddings]

    def vlm_understand_image(self, image_base64: str, question: str) -> str:
        """Qwen2-VL 图片理解"""
        from qwen_vl_utils import process_vision_info

        image_data = base64.b64decode(image_base64)
        image = Image.open(io.BytesIO(image_data)).convert('RGB')

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": question}
                ]
            }
        ]

        text = self.vlm_processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        image_inputs, video_inputs = process_vision_info(messages)

        inputs = self.vlm_processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt"
        ).to(self.vlm_model.device)

        outputs = self.vlm_model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=False
        )

        generated_ids = outputs[:, inputs.input_ids.shape[1]:]
        response = self.vlm_processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return response

    def llm_generate(self, prompt: str, max_tokens: int = 1024) -> str:
        """千问文本生成"""
        messages = [{"role": "user", "content": prompt}]
        text = self.llm_tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

        inputs = self.llm_tokenizer([text], return_tensors="pt").to(self.llm_model.device)
        outputs = self.llm_model.generate(
            **inputs,
            max_new_tokens=max_tokens,
            do_sample=False,
            pad_token_id=self.llm_tokenizer.eos_token_id
        )

        response = self.llm_tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
        return response


# ============================================================================
# FastAPI 服务
# ============================================================================

def create_app():
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel
    from typing import List, Optional

    app = FastAPI(title="Model Server", description="本地模型服务 - 完全离线")
    manager = ModelManager()

    class ClipEncodeRequest(BaseModel):
        image_base64: str

    class ClipEncodeBatchRequest(BaseModel):
        images_base64: List[str]

    class VLMRequest(BaseModel):
        image_base64: str
        question: str

    class LLMRequest(BaseModel):
        prompt: str
        max_tokens: int = 1024

    @app.get("/health")
    def health_check():
        return {
            "status": "ok",
            "models_loaded": manager.is_loaded()
        }

    @app.post("/clip/encode")
    def clip_encode(req: ClipEncodeRequest):
        if not manager.clip_model:
            raise HTTPException(500, "CLIP 模型未加载")
        embedding = manager.clip_encode_image(req.image_base64)
        return {"embedding": embedding}

    @app.post("/clip/encode_batch")
    def clip_encode_batch(req: ClipEncodeBatchRequest):
        if not manager.clip_model:
            raise HTTPException(500, "CLIP 模型未加载")
        embeddings = manager.clip_encode_images_batch(req.images_base64)
        return {"embeddings": embeddings}

    @app.post("/vlm/understand")
    def vlm_understand(req: VLMRequest):
        if not manager.vlm_model:
            raise HTTPException(500, "VLM 模型未加载")
        response = manager.vlm_understand_image(req.image_base64, req.question)
        return {"response": response}

    @app.post("/llm/generate")
    def llm_generate(req: LLMRequest):
        if not manager.llm_model:
            raise HTTPException(500, "LLM 模型未加载")
        response = manager.llm_generate(req.prompt, req.max_tokens)
        return {"response": response}

    return app, manager


# ============================================================================
# 主函数
# ============================================================================

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='模型服务器 - 预加载模型')
    parser.add_argument('--port', '-p', type=int, default=8100, help='服务端口 (默认 8100)')
    parser.add_argument('--host', type=str, default='127.0.0.1', help='绑定地址 (默认 127.0.0.1)')
    parser.add_argument('--vlm-path', type=str,
                        default="models/Qwen2-VL-7B-Instruct",
                        help='Qwen2-VL 模型路径')
    parser.add_argument('--llm-path', type=str,
                        default="models/Qwen2.5-7B-Instruct",
                        help='千问 LLM 模型路径')
    args = parser.parse_args()

    print("=" * 60)
    print("模型服务器 - 预加载模型，常驻内存")
    print("=" * 60)
    print(f"服务地址: http://{args.host}:{args.port}")
    print("完全离线运行，无需网络连接")
    print("=" * 60)

    # 创建应用和管理器
    app, manager = create_app()

    # 预加载所有模型
    manager.load_all(vlm_path=args.vlm_path, llm_path=args.llm_path)

    # 启动服务
    import uvicorn
    print(f"\n服务已启动: http://{args.host}:{args.port}")
    print("现在可以启动 Web 应用: python demo/app_pdf_chat.py --client")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
