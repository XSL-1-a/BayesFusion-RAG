#!/usr/bin/env python3
import sys
import os
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

# Load config
config_path = os.path.join(os.path.dirname(__file__), '../configs/model_config.yaml')
with open(config_path) as f:
    config = yaml.safe_load(f)

print(f"Model: {config['model']['name']} v{config['model']['version']}")
print("-" * 40)

import torch
from src.fusion.gating_network import MoREGatingNet

net_cfg = config['network']
net = MoREGatingNet(
    feature_dim=net_cfg['feature_dim'],
    n_experts=net_cfg['n_experts'],
    hidden_dim=net_cfg['hidden_dim'],
    dropout=net_cfg['dropout']
)

print(f"\nArchitecture:")
print(f"  Input:   {net_cfg['feature_dim']} dim")
print(f"  Hidden:  {net_cfg['hidden_dim']} dim")
print(f"  Experts: {net_cfg['n_experts']}")
print(f"\nExperts: {', '.join([e['name'] for e in config['experts']])}")

params = sum(p.numel() for p in net.parameters())
print(f"\nParameters: {params:,}")
print("-" * 40)
print("Network initialized successfully")
