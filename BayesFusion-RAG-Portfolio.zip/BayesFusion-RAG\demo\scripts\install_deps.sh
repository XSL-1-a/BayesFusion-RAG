#!/bin/bash
echo "Installing dependencies..."
pip install torch numpy transformers --quiet
echo "Dependencies installed."
