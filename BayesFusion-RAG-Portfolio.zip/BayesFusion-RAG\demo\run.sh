#!/bin/bash
# MoRE 私有PDF检索演示启动脚本

cd "$(dirname "$0")/.."

# 激活虚拟环境
source RAG/bin/activate

# 检查 gradio 是否安装
if ! python -c "import gradio" 2>/dev/null; then
    echo "安装 gradio..."
    pip install gradio -i https://pypi.tuna.tsinghua.edu.cn/simple
fi

# 启动应用
echo "=========================================="
echo "  MoRE 私有PDF检索演示系统"
echo "=========================================="
echo ""
echo "启动中..."
echo "请在浏览器中访问: http://localhost:7860"
echo ""

python demo/app.py
