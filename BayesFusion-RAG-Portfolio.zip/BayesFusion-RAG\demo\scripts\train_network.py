#!/usr/bin/env python3
import sys
import os
import yaml
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

import torch
import torch.nn as nn
import torch.optim as optim
from src.fusion.gating_network import MoREGatingNet

# Load config
config_path = os.path.join(os.path.dirname(__file__), '../configs/model_config.yaml')
with open(config_path) as f:
    config = yaml.safe_load(f)

train_cfg = config['training']
net_cfg = config['network']

print("=" * 50)
print("  MoRE Gating Network Training")
print("=" * 50)

# Init
net = MoREGatingNet(
    feature_dim=128,  # reduced for speed
    n_experts=net_cfg['n_experts'],
    hidden_dim=64
)
optimizer = optim.AdamW(net.parameters(), lr=train_cfg['learning_rate'])
loss_fn = nn.KLDivLoss(reduction='batchmean')

# Data
n_samples = 200
X = torch.randn(n_samples, 128)
Y = torch.softmax(torch.randn(n_samples, 4) * 2, dim=1)

print(f"\nConfig:")
print(f"  Optimizer: {train_cfg['optimizer']}")
print(f"  LR: {train_cfg['learning_rate']}")
print(f"  Samples: {n_samples}")
print()

# Train
epochs = 25
net.train()
start = time.time()

for epoch in range(epochs):
    optimizer.zero_grad()
    out = net(X)
    loss = loss_fn(torch.log(out.expert_weights + 1e-8), Y)
    loss.backward()
    optimizer.step()

    bar = "█" * int((epoch+1)/epochs*20) + "░" * (20-int((epoch+1)/epochs*20))
    print(f"\r  [{bar}] Epoch {epoch+1:2d}/{epochs}  Loss: {loss.item():.4f}", end="")

elapsed = time.time() - start
print(f"\n\nTraining completed in {elapsed:.1f}s")

# Save
ckpt_path = os.path.join(os.path.dirname(__file__), '../logs/model.pt')
torch.save(net.state_dict(), ckpt_path)
print(f"Model saved: logs/model.pt")
print("=" * 50)
