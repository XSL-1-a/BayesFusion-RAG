#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

print("Loading HEA-MRAG modules...")
print("-" * 40)

modules = {
    "src.preprocessing": "Document Preprocessing",
    "src.retrieval": "Hierarchical Retrieval (HMR)",
    "src.entity": "Entity-Aware RAG (EA-RAG)",
    "src.fusion": "MoRE Framework",
    "src.generation": "Traceable Generation (TAG)",
    "src.evaluation": "Evaluation Framework",
}

loaded = 0
for mod, desc in modules.items():
    try:
        __import__(mod)
        print(f"  [+] {desc}")
        loaded += 1
    except Exception as e:
        print(f"  [-] {desc}: {e}")

print("-" * 40)
print(f"Loaded {loaded}/{len(modules)} modules")
